"""Dooray 어시스턴트 오케스트레이터 (BaseAgent).

Google ADK BaseAgent + LlmAgent 조합으로 구현.
5가지 작업을 지원: Cloud-기록 조회 / SA-요청 조회 / 미팅기록·주간업무보고 생성 /
DX 댓글 추가 / 이메일 작성·전송.

일반 흐름:
  ┌──────────────────────────────────────────────┐
  │ 0) email_draft_pending 체크 (이메일 전용)    │
  │    → 대기 중이면 classifier 건너뜀           │
  │    → 승인/거부/수정 처리 후 종료             │
  │                                              │
  │ 1) classifier(LlmAgent, Gemini 3.5 Flash)    │
  │    → state["classification"] 채움            │
  │                                              │
  │ 2) merge: 이전 turn의 form 데이터와 병합     │
  │    → state[f"form:{intent}"] 갱신            │
  │                                              │
  │ 3) validate: 필수 파라미터 충족 여부 검사    │
  │    ├─ 부족 → 재질문 메시지 yield + return    │
  │    └─ OK   → 다음 단계                       │
  │                                              │
  │ 4-a) send_email → 초안 미리보기 생성          │
  │      → EventActions.state_delta로 persist    │
  │      → 다음 turn에서 승인/거부 대기          │
  │                                              │
  │ 4-b) 일반 작업 → Dooray API 함수 직접 호출   │
  │      → state["action_result_json"] 저장      │
  │                                              │
  │ 5) finalize(LlmAgent) — JSON → 마크다운       │
  │    또는 direct_answer(LlmAgent) — 일반응답   │
  │                                              │
  │ 6) form 정리 (성공한 경우)                    │
  └──────────────────────────────────────────────┘

* 재질문(ask_user) 케이스는 form 데이터를 유지하므로,
  사용자가 다음 turn에서 추가 정보를 주면 자연스럽게 누적된다.
* 이메일은 Human-in-the-loop 구조: 초안 → 승인/거부/수정 → 전송.
  state 영속화는 EventActions.state_delta로 처리 (VertexAiSessionService 호환).
"""

from __future__ import annotations

import json
import logging
from typing import Any, AsyncGenerator

from google.adk.agents import BaseAgent, LlmAgent
from google.adk.agents.invocation_context import InvocationContext
from google.adk.events import Event, EventActions
from google.genai import types
from typing_extensions import override

from . import tools as dooray_tools
from . import gmail_tools

logger = logging.getLogger(__name__)


# ============================================================
# 의도별 필수 파라미터 정의
# ============================================================

# record_type별 필수 파라미터
REQUIRED_FOR_MEETING: list[str] = [
    "customer", "meeting_date", "meeting_time", "location",
    "gs_attendees", "content",
]
REQUIRED_FOR_WEEKLY: list[str] = [
    "customer", "week_info", "project_name", "content",
]

REQUIRED_PARAMS: dict[str, list[str]] = {
    "list_records": [],
    "list_sa": [],
    "create_record": [],   # record_type에 따라 동적으로 결정 (아래 _missing_params에서 처리)
    "add_comment": ["comment_content"],
    "send_email": ["email_sender", "email_recipient", "email_subject", "email_body"],
    "direct_answer": [],
}

PARAM_LABEL_KO: dict[str, str] = {
    "record_type": "기록 유형 ('미팅기록' 또는 '주간업무보고')",
    "customer": "고객사명",
    "meeting_date": "미팅 날짜 (YYYY-MM-DD)",
    "meeting_time": "미팅 시간 (예: 13:00 ~ 14:00)",
    "location": "미팅 장소 (예: 화상 미팅)",
    "gs_attendees": "GS네오텍 참석자 (쉼표 구분, 첫 번째=영업/두 번째=SA)",
    "content": "내용 (미팅 내용 또는 금주 현황/차주 계획)",
    "history": "미팅 히스토리 (선택)",
    "action_items": "해야 할 일 (선택)",
    "week_info": "주차 정보 (예: 5월 2주차)",
    "project_name": "프로젝트/업무명",
    "comment_content": "댓글 내용",
    "post_id": "댓글 달 업무 ID 또는 검색 단서(담당자/키워드)",
    "email_sender": "보내는 사람 이메일 주소",
    "email_recipient": "받는 사람 이메일 주소",
    "email_subject": "이메일 제목",
    "email_body": "이메일 본문 내용",
    "email_cc": "참조(CC) 이메일 주소 (선택)",
}


# ============================================================
# 오케스트레이터
# ============================================================

class DoorayOrchestrator(BaseAgent):
    """Dooray 사내 어시스턴트의 루트 에이전트."""

    # ADK BaseAgent는 sub-agent들을 model fields로 선언해야 한다.
    classifier: LlmAgent
    direct_answer: LlmAgent
    finalizer: LlmAgent

    model_config = {"arbitrary_types_allowed": True}

    def __init__(
        self,
        name: str,
        classifier: LlmAgent,
        direct_answer: LlmAgent,
        finalizer: LlmAgent,
    ):
        super().__init__(
            name=name,
            classifier=classifier,
            direct_answer=direct_answer,
            finalizer=finalizer,
            sub_agents=[classifier, direct_answer, finalizer],
        )

    # ============================================================
    # 메인 실행
    # ============================================================

    def _log_ctx(self, ctx: InvocationContext) -> str:
        """로깅에 사용할 세션 컨텍스트 prefix를 생성한다."""
        sid = ctx.session.id[:8] if ctx.session.id else "?"
        uid = (ctx.session.user_id or "?")[:20]
        return f"[session={sid} user={uid}]"

    @override
    async def _run_async_impl(
        self, ctx: InvocationContext
    ) -> AsyncGenerator[Event, None]:
        tag = self._log_ctx(ctx)
        user_msg = self._get_last_user_message(ctx)
        logger.info("%s ── 새 turn 시작 ── input=%r", tag, user_msg[:100])

        # ─ 0. 이메일 초안 승인 대기 중이면 classifier 건너뜀 ─
        if ctx.session.state.get("email_draft_pending"):
            logger.info("%s 이메일 초안 대기 중 → email_feedback 처리", tag)
            async for event in self._handle_email_feedback(ctx):
                yield event
            return

        # ─ 1. 분류 ─
        logger.info("%s [1/6] classifier 호출", tag)
        async for event in self.classifier.run_async(ctx):
            if event.content and event.content.parts:
                event.content.parts = []
            yield event

        classification = self._get_classification(ctx)
        intent = classification.get("intent", "direct_answer")
        extracted = {k: v for k, v in classification.items() if v is not None and k != "intent"}
        logger.info("%s [1/6] 분류 결과: intent=%s params=%s", tag, intent, extracted)

        # ─ direct_answer ─
        if intent == "direct_answer":
            logger.info("%s [2/6] direct_answer 호출", tag)
            async for event in self.direct_answer.run_async(ctx):
                yield event
            logger.info("%s ── turn 종료 (direct_answer) ──", tag)
            return

        # ─ 2. form 병합 ─
        form_key = f"form:{intent}"
        merged = self._merge_form(ctx, form_key, classification)
        logger.info("%s [2/6] form 병합 완료: form_key=%s merged_keys=%s", tag, form_key, list(merged.keys()))

        # ─ 3. 파라미터 검증 ─
        missing = self._missing_params(intent, merged)
        if missing:
            logger.info("%s [3/6] 파라미터 부족 → 재질문: missing=%s", tag, missing)
            yield self._build_ask_user_event(ctx, intent, missing, merged)
            logger.info("%s ── turn 종료 (ask_user) ──", tag)
            return
        logger.info("%s [3/6] 파라미터 검증 통과", tag)

        # ─ 4. send_email → 초안 확인 후 승인 대기 ─
        #    email_draft_pending / email_draft 는 다음 turn에서 읽어야 하므로
        #    EventActions.state_delta로 저장해야 VertexAiSessionService에 persist 된다.
        if intent == "send_email":
            logger.info("%s [4/6] 이메일 초안 생성 → 승인 대기", tag)
            yield self._build_email_draft_event(ctx, merged)
            logger.info("%s ── turn 종료 (email_draft_pending) ──", tag)
            return

        # ─ 4. 일반 작업 실행 ─
        logger.info("%s [4/6] action 실행: intent=%s", tag, intent)
        try:
            result = self._run_action(intent, merged)
        except Exception as e:
            logger.exception("%s [4/6] action 실행 중 예외", tag)
            result = {"error": f"내부 오류가 발생했습니다: {e}"}

        has_error = bool(result.get("error")) or result.get("success") is False
        logger.info(
            "%s [4/6] action 결과: success=%s error=%s",
            tag, not has_error, result.get("error", "없음"),
        )

        ctx.session.state["action_result_json"] = json.dumps(result, ensure_ascii=False, indent=2)

        # ─ 5. finalize ─
        logger.info("%s [5/6] finalizer 호출", tag)
        async for event in self.finalizer.run_async(ctx):
            yield event

        # ─ 6. form 정리 ─
        if not has_error:
            ctx.session.state[form_key] = {}
            logger.info("%s [6/6] form 정리 완료: %s", tag, form_key)

        logger.info("%s ── turn 종료 (action=%s) ──", tag, intent)

    # ============================================================
    # 헬퍼 함수
    # ============================================================

    def _get_classification(self, ctx: InvocationContext) -> dict[str, Any]:
        """classifier가 state["classification"]에 저장한 결과를 dict로 꺼낸다.

        ADK는 output_schema 사용 시 LLM 응답 텍스트(JSON)를 state에 저장하므로,
        문자열일 경우 파싱하고 dict일 경우 그대로 사용한다.
        """
        raw = ctx.session.state.get("classification", {})
        if isinstance(raw, str):
            try:
                return json.loads(raw)
            except json.JSONDecodeError:
                logger.warning("classification이 dict/JSON이 아님: %r", raw)
                return {"intent": "direct_answer"}
        return raw or {"intent": "direct_answer"}

    def _merge_form(
        self,
        ctx: InvocationContext,
        form_key: str,
        classification: dict[str, Any],
    ) -> dict[str, Any]:
        """이전 turn의 부분 수집 데이터와 이번 turn의 새 추출 결과를 병합한다."""
        previous = ctx.session.state.get(form_key, {}) or {}
        new_values = {
            k: v for k, v in classification.items()
            if v is not None and k != "intent"
        }
        merged = {**previous, **new_values}
        ctx.session.state[form_key] = merged
        return merged

    def _missing_params(self, intent: str, merged: dict[str, Any]) -> list[str]:
        """현재 의도의 필수 파라미터 중 비어있는 것을 반환한다."""
        # create_record는 record_type에 따라 필수 파라미터가 다르다.
        if intent == "create_record":
            record_type = merged.get("record_type")
            if not record_type:
                return ["record_type"]
            if record_type == "미팅기록":
                return [p for p in REQUIRED_FOR_MEETING if not merged.get(p)]
            if record_type == "주간업무보고":
                return [p for p in REQUIRED_FOR_WEEKLY if not merged.get(p)]

        missing = [p for p in REQUIRED_PARAMS.get(intent, []) if not merged.get(p)]

        # add_comment 특수 케이스: post_id가 없을 때 검색 단서가 있는지 확인.
        if intent == "add_comment" and not merged.get("post_id"):
            search_hint = any(
                merged.get(k)
                for k in ("comment_keyword", "customer", "assignee_name")
            )
            if not search_hint:
                missing.append("post_id")

        return missing

    def _build_ask_user_event(
        self,
        ctx: InvocationContext,
        intent: str,
        missing: list[str],
        merged: dict[str, Any],
    ) -> Event:
        """필수 파라미터가 부족할 때 사용자에게 보낼 재질문 메시지를 만든다.

        VertexAiSessionService는 Event에 invocation_id가 필수이므로 ctx에서 가져온다.
        """
        record_type = merged.get("record_type", "")
        intent_label = {
            "create_record": f"{record_type or '기록'} 생성",
            "add_comment": "DX 업무 댓글 추가",
            "send_email": "이메일 전송",
        }.get(intent, "요청")

        lines = [f"{intent_label}을 위해 다음 정보가 더 필요합니다:\n"]
        for param in missing:
            lines.append(f"- **{PARAM_LABEL_KO.get(param, param)}**")

        already = {
            k: v for k, v in merged.items()
            if v and k not in missing
        }
        if already:
            lines.append("\n_이미 받은 정보:_")
            for k, v in already.items():
                label = PARAM_LABEL_KO.get(k, k)
                preview = v if len(str(v)) < 60 else str(v)[:60] + "..."
                lines.append(f"- {label}: {preview}")

        # 이메일 작성 시 사내 그룹메일 안내
        if intent == "send_email":
            from .config import GROUP_EMAILS
            lines.append("\n---\n📋 **참고: 사내 그룹메일 목록**")
            for team, email in GROUP_EMAILS.items():
                lines.append(f"- {team}: `{email}`")

        return Event(
            invocation_id=ctx.invocation_id,
            author=self.name,
            content=types.Content(
                role="model",
                parts=[types.Part(text="\n".join(lines))],
            ),
        )

    def _run_action(self, intent: str, params: dict[str, Any]) -> dict[str, Any]:
        """검증을 통과한 의도에 맞는 Dooray API 함수를 호출한다."""
        if intent == "list_records":
            return dooray_tools.list_cloud_records(
                customer=params.get("customer"),
                tag_name=params.get("tag_name"),
                assignee_name=params.get("assignee_name"),
                days=params.get("lookup_days"),
            )
        if intent == "list_sa":
            return dooray_tools.list_sa_requests(
                customer=params.get("customer"),
                status=params.get("sa_status"),
                assignee_name=params.get("assignee_name"),
                days=params.get("lookup_days"),
            )
        if intent == "create_record":
            record_type = params.get("record_type")
            if record_type == "주간업무보고":
                return dooray_tools.create_weekly_report(
                    customer=params["customer"],
                    week_info=params["week_info"],
                    project_name=params["project_name"],
                    content=params["content"],
                    cloud_type=params.get("cloud_type"),
                )
            # 기본값: 미팅기록
            return dooray_tools.create_meeting_record(
                customer=params["customer"],
                meeting_date=params["meeting_date"],
                meeting_time=params["meeting_time"],
                location=params["location"],
                gs_attendees=params["gs_attendees"],
                content=params["content"],
                customer_attendees=params.get("customer_attendees"),
                cloud_type=params.get("cloud_type"),
                other_attendees=params.get("other_attendees"),
                history=params.get("history"),
                action_items=params.get("action_items"),
            )
        if intent == "add_comment":
            return self._handle_add_comment(params)
        return {"error": f"알 수 없는 의도: {intent}"}

    def _handle_add_comment(self, params: dict[str, Any]) -> dict[str, Any]:
        """post_id가 직접 있으면 바로 댓글, 없으면 검색 후 1건 매칭 시 자동 진행."""
        content = params["comment_content"]

        # post_id가 직접 주어진 경우
        if params.get("post_id"):
            return dooray_tools.add_dx_task_comment(
                post_id=params["post_id"], content=content
            )

        # 검색 단서로 후보 찾기
        search = dooray_tools.list_dx_tasks(
            assignee_name=params.get("assignee_name"),
            keyword=params.get("comment_keyword") or params.get("customer"),
            size=10,
        )
        if search.get("error"):
            return search

        tasks = search.get("tasks", [])
        if len(tasks) == 1:
            result = dooray_tools.add_dx_task_comment(
                post_id=tasks[0]["id"], content=content
            )
            result["matched_task_subject"] = tasks[0]["subject"]
            return result

        # 0건 또는 다수 → 사용자 선택 필요 (검색 결과를 finalizer가 표시)
        return {
            "needs_user_pick": True,
            "search": search,
            "pending_comment": content,
        }

    # ============================================================
    # 이메일: 초안 미리보기 + Human Feedback + 전송
    # ============================================================

    def _get_last_user_message(self, ctx: InvocationContext) -> str:
        """세션 이벤트에서 마지막 사용자 메시지 텍스트를 추출한다."""
        for event in reversed(ctx.session.events or []):
            if event.content and event.content.role == "user" and event.content.parts:
                for part in event.content.parts:
                    if part.text:
                        return part.text
        return ""

    def _build_email_draft_event(
        self, ctx: InvocationContext, params: dict[str, Any]
    ) -> Event:
        """이메일 초안을 마크다운으로 보여주는 Event를 만든다."""
        lines = [
            "## 📧 이메일 초안\n",
            f"**보내는 사람:** {params.get('email_sender', '')}",
            f"**받는 사람:** {params.get('email_recipient', '')}",
        ]
        if params.get("email_cc"):
            lines.append(f"**참조(CC):** {params['email_cc']}")
        lines.extend([
            f"**제목:** {params.get('email_subject', '')}",
            "",
            "---",
            "",
            params.get("email_body", ""),
            "",
            "---",
            "",
            "위 내용으로 이메일을 전송할까요?",
            "- **전송** → '보내줘', '고고', 'ㄱㄱ' 등",
            "- **취소** → '취소', '안 보낼래' 등",
            "- **수정** → '제목 바꿔줘', '본문에 ~~ 추가해줘' 등",
        ])
        return Event(
            invocation_id=ctx.invocation_id,
            author=self.name,
            content=types.Content(
                role="model",
                parts=[types.Part(text="\n".join(lines))],
            ),
            actions=EventActions(
                state_delta={
                    "email_draft_pending": True,
                    "email_draft": params,
                },
            ),
        )

    def _judge_email_feedback(self, user_msg: str, draft: dict[str, Any]) -> dict[str, Any]:
        """LLM으로 사용자의 이메일 피드백 의도를 판단한다.

        Returns:
            {"decision": "approve" | "deny" | "revise", "revised_draft": {...} | None}
        """
        from .sub_agents import EMAIL_FEEDBACK_LLM

        draft_preview = (
            f"제목: {draft.get('email_subject', '')}\n"
            f"받는 사람: {draft.get('email_recipient', '')}\n"
            f"본문: {draft.get('email_body', '')[:200]}"
        )

        prompt = f"""이메일 초안에 대한 사용자 피드백을 분석하세요.

현재 초안:
{draft_preview}

사용자 응답: "{user_msg}"

아래 3가지 중 하나로 판단하세요:
1. "approve" — 사용자가 전송을 승인/동의 (예: "보내줘", "ㄱㄱ", "고고", "좋아", "네", "ok" 등)
2. "deny" — 사용자가 전송을 취소/거부 (예: "취소", "안 보낼래", "그만" 등)
3. "revise" — 사용자가 초안 수정을 요청 (예: "제목 바꿔줘", "본문에 ~~ 추가해줘" 등)

revise인 경우 수정된 초안을 함께 제공하세요.

반드시 아래 JSON 형식으로만 응답하세요:
{{"decision": "approve|deny|revise", "revised_subject": "수정된 제목 (revise일 때만)", "revised_body": "수정된 본문 (revise일 때만)"}}"""

        try:
            response = EMAIL_FEEDBACK_LLM.generate_content(
                contents=[{"role": "user", "parts": [{"text": prompt}]}],
            )
            text = response.text.strip()
            # JSON 추출 (```json ... ``` 감쌌을 수도 있으므로)
            if "```" in text:
                text = text.split("```")[1]
                if text.startswith("json"):
                    text = text[4:]
            return json.loads(text.strip())
        except Exception as e:
            logger.warning("이메일 피드백 LLM 판단 실패: %s — 키워드 폴백 사용", e)
            # LLM 실패 시 단순 키워드 폴백
            msg = user_msg.lower()
            if any(kw in msg for kw in ["보내", "전송", "네", "ㅇㅇ", "ok", "yes", "고고", "ㄱㄱ"]):
                return {"decision": "approve"}
            if any(kw in msg for kw in ["취소", "안 보", "아니", "ㄴㄴ", "no"]):
                return {"decision": "deny"}
            return {"decision": "revise"}

    async def _handle_email_feedback(
        self, ctx: InvocationContext
    ) -> AsyncGenerator[Event, None]:
        """이메일 초안에 대한 사용자 승인/거부/수정 요청을 처리한다.

        LLM(Haiku)이 사용자 응답을 approve/deny/revise 3가지로 판단한다.
        revise이면 수정 반영 후 초안 재생성 → 다시 승인 대기.
        """
        tag = self._log_ctx(ctx)
        user_msg = self._get_last_user_message(ctx)
        draft = ctx.session.state.get("email_draft", {})

        if not draft:
            logger.warning("%s email_draft가 비어있음 → pending 해제", tag)
            ctx.session.state["email_draft_pending"] = False
            return

        logger.info("%s email_feedback: LLM 판단 요청, user_msg=%r", tag, user_msg[:80])
        judgment = self._judge_email_feedback(user_msg, draft)
        decision = judgment.get("decision", "revise")
        logger.info("%s email_feedback: decision=%s", tag, decision)

        if decision == "approve":
            logger.info("%s email → 승인 → Gmail 전송 시작 (to=%s)", tag, draft.get("email_recipient"))
            result = gmail_tools.send_gmail(
                sender=draft.get("email_sender", ""),
                to=draft.get("email_recipient", ""),
                subject=draft.get("email_subject", ""),
                body=draft.get("email_body", ""),
                cc=draft.get("email_cc"),
            )
            logger.info("%s email → 전송 결과: success=%s", tag, result.get("success"))
            # action_result_json은 같은 turn 내에서 finalizer가 읽으므로 직접 쓰기 OK
            ctx.session.state["action_result_json"] = json.dumps(
                result, ensure_ascii=False, indent=2
            )
            # email state 초기화는 다음 turn에 영향 → state_delta로 persist
            yield Event(
                invocation_id=ctx.invocation_id,
                author=self.name,
                actions=EventActions(
                    state_delta={
                        "email_draft_pending": False,
                        "email_draft": {},
                    },
                ),
            )
            async for event in self.finalizer.run_async(ctx):
                yield event
            logger.info("%s ── turn 종료 (email_sent) ──", tag)

        elif decision == "deny":
            logger.info("%s email → 거부 → 초안 폐기", tag)
            yield Event(
                invocation_id=ctx.invocation_id,
                author=self.name,
                content=types.Content(
                    role="model",
                    parts=[types.Part(text="이메일 전송이 취소되었습니다.")],
                ),
                actions=EventActions(
                    state_delta={
                        "email_draft_pending": False,
                        "email_draft": {},
                    },
                ),
            )
            logger.info("%s ── turn 종료 (email_denied) ──", tag)

        else:
            logger.info("%s email → 수정 요청 → 초안 재생성", tag)
            if judgment.get("revised_subject"):
                draft["email_subject"] = judgment["revised_subject"]
            if judgment.get("revised_body"):
                draft["email_body"] = judgment["revised_body"]
            # 수정된 초안을 다시 보여줌 — _build_email_draft_event가 state_delta로 persist
            yield self._build_email_draft_event(ctx, draft)
            logger.info("%s ── turn 종료 (email_revised, 재승인 대기) ──", tag)