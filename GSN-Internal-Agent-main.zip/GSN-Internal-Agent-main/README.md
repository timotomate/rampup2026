# GSN Internal Agent (Doo-B)

GS네오텍 Cloud팀 전용 사내 Dooray 어시스턴트 **"Doo-B(두비)"**.  
Google ADK(Agent Development Kit) 기반으로 구축되어, Vertex AI Agent Engine에 배포 후 Gemini Enterprise(Agentspace)에 Custom Agent로 등록하여 사용합니다.

---

## Architecture

![Agentic Workflow](agentic_workflow.png)

### 에이전트 구성

| 에이전트 | 모델 | 역할 |
|---------|------|------|
| **DoorayOrchestrator** | (BaseAgent) | 전체 흐름 통제: 분류 → 검증 → 라우팅 → 실행 → 마무리 |
| **classifier** | Gemini 3.5 Flash | 사용자 의도 분류 + 파라미터 추출 (Pydantic 강제) |
| **direct_answer** | Gemini 3.1 Flash Lite | 일반 질문/인사/사용법 안내 응답 |
| **finalizer** | Claude Haiku 4.5 | 도구 실행 결과(JSON) → 한국어 마크다운 변환 |
| **email_feedback** | Claude Sonnet 4.6 | 이메일 초안 승인/거부/수정 의도 판단 |

### 지원 작업 (5가지)

| # | 작업 | 설명 |
|---|------|------|
| 1 | **Cloud-기록 조회** | 미팅기록/주간업무보고 조회 (고객사/태그/담당자/기간 필터) |
| 2 | **Cloud-SA-요청 조회** | SA 지원 요청 조회 (고객사/상태/담당자/기간 필터) |
| 3 | **미팅기록·주간업무보고 생성** | 필수 파라미터 수집 후 Dooray API로 자동 생성 |
| 4 | **DX파트-업무 댓글 추가** | 업무 검색 → 댓글 작성 |
| 5 | **이메일 작성·전송** | 초안 생성 → 사용자 승인(Human-in-the-loop) → Gmail 전송 |

---

## Tech Stack

- **Framework**: [Google ADK](https://adk.dev/) (BaseAgent + LlmAgent)
- **LLM**: Gemini 3.5 Flash (분류) + Gemini 3.1 Flash Lite (일반 응답) + Claude Haiku 4.5 (마크다운 변환) + Claude Sonnet 4.6 (이메일 판단)
- **배포**: Vertex AI Agent Engine → Gemini Enterprise Custom Agent
- **외부 API**: Dooray REST API, Gmail API (OAuth2)
- **Telemetry**: Cloud Trace (OTEL)

---

## Project Structure

```
ge_adk_agent/
├── __init__.py             # 패키지 진입점 (root_agent export)
├── agent.py                # ADK 진입점 (DoorayOrchestrator 인스턴스 생성)
├── orchestrator.py         # 오케스트레이터 (BaseAgent) — 전체 흐름 통제
├── sub_agents.py           # LlmAgent 3종 (classifier / direct_answer / finalizer)
├── config.py               # 프로젝트 ID, 5팀 66명 멤버, 태그/워크플로우 매핑, 그룹메일
├── tools.py                # Dooray REST API 호출 함수 6종
├── gmail_tools.py          # Gmail API 전송 (OAuth2 토큰 관리)
├── schemas.py              # ClassificationResult (Pydantic 의도 분류 스키마)
├── prompts.py              # LLM instruction 모음 (classifier / direct_answer / finalizer)
├── deploy.py               # Vertex AI Agent Engine 배포 (신규 생성 / in-place 업데이트)
├── create_gmail_token.py   # Gmail OAuth2 토큰 최초 생성 스크립트 (로컬 실행)
├── requirements.txt        # Python 의존성
└── .env.example            # 환경변수 템플릿
```

---

## Setup

### 사전 준비

- Python 3.11+
- `gcloud auth login && gcloud auth application-default login`
- GCP 프로젝트에서 Claude Sonnet 4.6, Claude Haiku 4.5 모델 활성화 (Vertex AI Model Garden)

### 환경변수 설정

```bash
cp .env.example .env
# .env 파일에 DOORAY_API_TOKEN 등 입력
```

### 의존성 설치

```bash
pip install -r requirements.txt
```

### Gmail 토큰 생성 (최초 1회)

```bash
python create_gmail_token.py
# 브라우저 OAuth 인증 → token.json 생성
# 출력된 GMAIL_TOKEN_JSON 값을 .env에 추가
```

---

## Deployment

### 신규 배포

```bash
cd /path/to/parent_directory
PYTHONIOENCODING=utf-8 python -m ge_adk_agent.deploy
```

### 기존 리소스 업데이트

```bash
EXISTING_RESOURCE_NAME='projects/.../reasoningEngines/...' \
  PYTHONIOENCODING=utf-8 python -m ge_adk_agent.deploy
```

### 환경변수 (Agent Engine)

| 변수 | 설명 |
|------|------|
| `GOOGLE_CLOUD_LOCATION` | `global` (Gemini 모델 호출용) |
| `GOOGLE_GENAI_USE_VERTEXAI` | `True` |
| `DOORAY_API_TOKEN` | Dooray 개인 API 토큰 |
| `CLAUDE_MODEL` | `claude-sonnet-4-6`(기본 모델. haiku는 별도 지정) |
| `GMAIL_TOKEN_JSON` | Gmail OAuth2 토큰 (JSON 문자열) |
| `GOOGLE_CLOUD_AGENT_ENGINE_ENABLE_TELEMETRY` | `True` |
| `OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT` | `True` |

---

## Key Design Decisions

### 1. BaseAgent 커스텀 오케스트레이터
LLM-driven delegation 대신 **명시적 Python 흐름 통제**를 사용합니다.  
의도 분류 → 파라미터 검증 → 라우팅이 결정론적으로 동작하여 디버깅과 흐름 추적이 용이합니다.

### 2. 이메일 Human-in-the-loop
이메일은 즉시 전송하지 않고 **초안 → 사용자 승인/거부/수정 → 전송** 3단계로 동작합니다.  
승인/거부/수정 판단은 Claude Sonnet 4.6이 수행하여 "고고", "ㄱㄱ" 같은 비정형 표현도 인식합니다.  
state 영속화는 `EventActions.state_delta`를 사용하여 VertexAiSessionService와 호환됩니다.

### 3. Classifier JSON 외부 노출 차단
classifier(output_schema)의 raw JSON 응답이 사용자에게 보이지 않도록  
`event.content.parts = []`로 텍스트를 비우고 yield합니다.  
state_delta는 별도로 commit되므로 `state["classification"]`은 정상 저장됩니다.

### 4. 구조화된 로깅
매 turn마다 `[session=... user=...]` 태그와 함께 단계별 로그를 남겨  
Cloud Logging에서 특정 세션의 에이전트 흐름을 직관적으로 추적할 수 있습니다.
