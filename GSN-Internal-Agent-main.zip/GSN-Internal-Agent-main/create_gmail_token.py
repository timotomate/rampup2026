"""Gmail OAuth2 토큰 최초 생성 스크립트.

로컬에서 실행하면 token.json이 생성.
Agent Engine 배포 시에는 token.json 내용을 환경변수 GMAIL_TOKEN_JSON에 넣으면 됨.

사용:
    source /c/workspace/mhk_venv/Scripts/activate
    pip install google-api-python-client google-auth google-auth-oauthlib
    cd /c/Python/dooray/ge_adk_agent
    python create_gmail_token.py
"""

from __future__ import annotations

import os
import json

SCOPES = ["https://www.googleapis.com/auth/gmail.send"]
CREDENTIALS_PATH = os.path.join(os.path.dirname(__file__), "credentials.json")
TOKEN_PATH = os.path.join(os.path.dirname(__file__), "token.json")


def main() -> None:
    from google_auth_oauthlib.flow import InstalledAppFlow

    if not os.path.exists(CREDENTIALS_PATH):
        raise FileNotFoundError(f"{CREDENTIALS_PATH} 파일이 존재하지 않습니다.")

    flow = InstalledAppFlow.from_client_secrets_file(CREDENTIALS_PATH, SCOPES)
    creds = flow.run_local_server(port=8782)

    with open(TOKEN_PATH, "w") as f:
        f.write(creds.to_json())

    print(f"token.json이 생성되었습니다: {TOKEN_PATH}")
    print()
    print("Agent Engine 배포 시 아래 내용을 .env의 GMAIL_TOKEN_JSON에 한 줄로 넣으세요:")
    print()

    with open(TOKEN_PATH, "r") as f:
        token_data = json.load(f)
    print(f"GMAIL_TOKEN_JSON={json.dumps(token_data, ensure_ascii=False)}")


if __name__ == "__main__":
    main()
