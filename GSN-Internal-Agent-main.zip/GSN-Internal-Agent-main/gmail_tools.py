"""Gmail API를 사용한 이메일 전송.

OAuth2 토큰(token.json 또는 환경변수 GMAIL_TOKEN_JSON)으로 인증한다.
최초 토큰 생성은 create_gmail_token.py를 로컬에서 실행해야 한다.
"""

from __future__ import annotations

import base64
import json
import logging
import os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Optional

logger = logging.getLogger(__name__)

SCOPES = ["https://www.googleapis.com/auth/gmail.send"]
CREDENTIALS_PATH = os.path.join(os.path.dirname(__file__), "credentials.json")
TOKEN_PATH = os.path.join(os.path.dirname(__file__), "token.json")


def _get_gmail_service():
    """Gmail API 서비스 객체를 반환한다.

    토큰 소스 우선순위:
      1. 환경변수 GMAIL_TOKEN_JSON (Agent Engine 배포용)
      2. 파일 token.json (로컬 개발용)
    """
    from google.auth.transport.requests import Request
    from google.oauth2.credentials import Credentials
    from googleapiclient.discovery import build

    creds = None

    # 1) 환경변수에서 토큰 읽기 (Agent Engine 환경)
    token_json_str = os.environ.get("GMAIL_TOKEN_JSON", "")
    if token_json_str:
        token_data = json.loads(token_json_str)
        creds = Credentials.from_authorized_user_info(token_data, SCOPES)

    # 2) 파일에서 토큰 읽기 (로컬 환경)
    if not creds and os.path.exists(TOKEN_PATH):
        creds = Credentials.from_authorized_user_file(TOKEN_PATH, SCOPES)

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
            # 갱신된 토큰을 파일에 저장 (로컬)
            if os.path.exists(TOKEN_PATH):
                with open(TOKEN_PATH, "w") as f:
                    f.write(creds.to_json())
        else:
            raise RuntimeError(
                "유효한 Gmail 토큰이 없습니다. "
                "로컬에서 create_gmail_token.py를 실행해 token.json을 생성하세요."
            )

    return build("gmail", "v1", credentials=creds)


def send_gmail(
    sender: str,
    to: str,
    subject: str,
    body: str,
    cc: Optional[str] = None,
) -> dict:
    """Gmail API로 이메일을 전송한다.

    Args:
        sender: 보내는 사람 이메일 주소.
        to: 받는 사람 이메일 주소 (여러 명이면 쉼표 구분).
        subject: 이메일 제목.
        body: 이메일 본문 (HTML 지원).
        cc: 참조 이메일 주소 (선택, 여러 명이면 쉼표 구분).

    Returns:
        전송 결과 dict. success, message_id 또는 error.
    """
    try:
        service = _get_gmail_service()
    except Exception as e:
        logger.exception("Gmail 서비스 초기화 실패")
        return {"success": False, "error": f"Gmail 인증 실패: {e}"}

    # MIME 메시지 구성
    message = MIMEMultipart()
    message["to"] = to
    message["from"] = sender
    message["subject"] = subject
    if cc:
        message["cc"] = cc

    msg_body = MIMEText(body, "html")
    message.attach(msg_body)

    # base64 인코딩
    raw = base64.urlsafe_b64encode(message.as_bytes()).decode("utf-8")

    try:
        sent = service.users().messages().send(
            userId="me", body={"raw": raw}
        ).execute()
        message_id = sent.get("id", "")
        logger.info("Gmail 전송 성공: message_id=%s", message_id)
        return {
            "success": True,
            "message_id": message_id,
            "to": to,
            "subject": subject,
            "message": "이메일이 전송되었습니다.",
        }
    except Exception as e:
        logger.exception("Gmail 전송 실패")
        return {"success": False, "error": f"이메일 전송 실패: {e}"}
