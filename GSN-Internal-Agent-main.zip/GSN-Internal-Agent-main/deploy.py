"""ge_adk_agent → Vertex AI Agent Engine 배포 스크립트.

동작 방식:
- 환경변수 EXISTING_RESOURCE_NAME 이 지정되면 → 해당 리소스 in-place 업데이트
- 지정되지 않으면 → 신규 reasoning engine 생성

사용:
    source /c/workspace/mhk_venv/Scripts/activate
    cd /c/Python/dooray

    # 신규 배포:
    PYTHONIOENCODING=utf-8 python -m ge_adk_agent.deploy

    # 기존 리소스 업데이트:
    EXISTING_RESOURCE_NAME='projects/.../reasoningEngines/...' \\
        PYTHONIOENCODING=utf-8 python -m ge_adk_agent.deploy

Telemetry는 `enable_tracing` 대신 다음 두 환경변수로 활성화:
  - GOOGLE_CLOUD_AGENT_ENGINE_ENABLE_TELEMETRY=True
  - OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT=True
"""

from __future__ import annotations

import os
import sys

from dotenv import load_dotenv

# 패키지 경로의 .env 우선 로드
load_dotenv(os.path.join(os.path.dirname(__file__), ".env"))

from .config import GCP_LOCATION, GCP_PROJECT_ID
from .agent import root_agent


# 기존 리소스 in-place 업데이트 대상 (없으면 새로 생성). 명시적 ID만 다룸.
EXISTING_RESOURCE_NAME = os.environ.get("EXISTING_RESOURCE_NAME", "").strip()

DISPLAY_NAME = "dooray-adk-custom-agent"
DESCRIPTION = (
    "GS네오텍 Cloud팀 전체 사내 Dooray 어시스턴트 (ADK 기반). "
    "BaseAgent + LlmAgent로 의도 분류→검증→재질문→실행→마무리. "
    "5가지 작업: Cloud-기록 조회 / Cloud-SA-요청 조회 / 미팅기록·주간업무보고 생성 / DX 댓글 추가 / 이메일 작성·전송."
)


def _build_app():
    """AdkApp 인스턴스를 생성한다. Agent Engine이 이것을 직렬화·배포."""
    from vertexai.preview.reasoning_engines import AdkApp

    return AdkApp(agent=root_agent)


def _common_kwargs() -> dict:
    """create / update 양쪽이 공유하는 패키지·환경변수 설정."""
    requirements = [
        "google-cloud-aiplatform[agent_engines,adk]>=1.112.0",
        "google-adk>=1.32.0",
        "litellm>=1.50.0",
        "anthropic[vertex]>=0.40.0",
        "google-api-python-client>=2.100.0",
        "google-auth>=2.20.0",
        "google-auth-oauthlib>=1.0.0",
        "requests>=2.32.0",
        "python-dotenv>=1.0.0",
        "pydantic>=2.0.0",
    ]
    env_vars = {
        # ─── Google ADK 표준 (Gemini 모델 호출에 필요) ───
        # GOOGLE_CLOUD_PROJECT는 Agent Engine이 자동 주입 (예약 변수)
        "GOOGLE_CLOUD_LOCATION": "global",
        "GOOGLE_GENAI_USE_VERTEXAI": "True",
        # ─── Agent Engine 배포 region ───
        "GCP_PROJECT_ID": GCP_PROJECT_ID,
        "GCP_LOCATION": GCP_LOCATION,
        # ─── Claude (Vertex AI Model Garden, LiteLlm 경유) ───
        "CLAUDE_LOCATION": os.environ.get("CLAUDE_LOCATION", "global"),
        "CLAUDE_MODEL": "claude-sonnet-4-6",
        "VERTEXAI_PROJECT": GCP_PROJECT_ID,
        "VERTEXAI_LOCATION": os.environ.get("CLAUDE_LOCATION", "global"),
        # ─── Dooray API ───
        "DOORAY_API_TOKEN": os.environ["DOORAY_API_TOKEN"],
        "DOORAY_WEB_BASE": os.environ.get("DOORAY_WEB_BASE", "https://gsn.dooray.com"),
        "DEFAULT_LOOKUP_DAYS": os.environ.get("DEFAULT_LOOKUP_DAYS", "30"),
        "DEFAULT_PAGE_SIZE": os.environ.get("DEFAULT_PAGE_SIZE", "100"),
        # ─── Gmail (OAuth2 토큰) ───
        "GMAIL_TOKEN_JSON": os.environ.get("GMAIL_TOKEN_JSON", ""),
        # ─── Telemetry ───
        "GOOGLE_CLOUD_AGENT_ENGINE_ENABLE_TELEMETRY": "True",
        "OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT": "True",
    }
    return {
        "requirements": requirements,
        "env_vars": env_vars,
        "extra_packages": ["./ge_adk_agent"],
    }


def main() -> None:
    import vertexai
    from vertexai import agent_engines

    vertexai.init(
        project=GCP_PROJECT_ID,
        location=GCP_LOCATION,
        staging_bucket=f"gs://{GCP_PROJECT_ID}-agent-engine-staging",
    )

    print("[1/3] AdkApp 인스턴스 생성 중...", flush=True)
    app = _build_app()
    kwargs = _common_kwargs()

    if EXISTING_RESOURCE_NAME:
        # === in-place 업데이트 모드 ===
        print(f"[2/3] 기존 리소스 in-place 업데이트: {EXISTING_RESOURCE_NAME}", flush=True)
        remote_agent = agent_engines.get(EXISTING_RESOURCE_NAME)
        print(f"       대상 display_name={remote_agent.display_name}", flush=True)
        remote_agent.update(agent_engine=app, **kwargs)
        print("[3/3] 업데이트 완료!", flush=True)
        print(f"\n  Resource name: {remote_agent.resource_name}", flush=True)
    else:
        # === 신규 생성 모드 ===
        print("[2/3] 신규 Agent Engine 배포 시작 (수 분 소요)...", flush=True)
        remote_agent = agent_engines.create(
            app,
            display_name=DISPLAY_NAME,
            description=DESCRIPTION,
            **kwargs,
        )
        print("[3/3] 신규 배포 완료!", flush=True)
        print(f"\n  Resource name: {remote_agent.resource_name}", flush=True)

    print(
        f"\nCloud Trace 확인: "
        f"https://console.cloud.google.com/traces/list?project={GCP_PROJECT_ID}",
        flush=True,
    )


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n사용자에 의해 중단됨.", file=sys.stderr)
        sys.exit(130)