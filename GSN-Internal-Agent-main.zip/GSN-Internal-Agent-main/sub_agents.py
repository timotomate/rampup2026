"""ADK LlmAgent 3종 + LLM 인스턴스 정의.

오케스트레이터(BaseAgent)가 명시적으로 호출하는 LLM 기반 보조 에이전트들.

  - classifier        : 의도 분류 + 파라미터 추출 → Gemini 3.5 Flash (ADK 네이티브)
  - direct_answer     : 일반 응답                → Gemini 3.1 Flash Lite (ADK 네이티브)
  - finalizer         : JSON → 마크다운 변환     → Claude Haiku 4.5 (LiteLlm)
  + EMAIL_FEEDBACK_LLM: 이메일 승인/거부/수정 판단 → Claude Sonnet 4.6 (LiteLlm)
"""

from __future__ import annotations

import os
from datetime import datetime, timedelta, timezone

from google.adk.agents import LlmAgent
from google.adk.models.lite_llm import LiteLlm

from .config import ALL_MEMBERS, GCP_PROJECT_ID
from .prompts import (
    DIRECT_ANSWER_INSTRUCTION,
    FINALIZE_INSTRUCTION,
    build_classify_instruction,
)
from .schemas import ClassificationResult


# ============================================================
# LLM 인스턴스
# ============================================================

def _init_vertex_env() -> None:
    """LiteLLM이 Vertex AI를 호출할 수 있도록 표준 환경변수를 보장한다."""
    os.environ.setdefault("VERTEXAI_PROJECT", GCP_PROJECT_ID)
    os.environ.setdefault("VERTEXAI_LOCATION", os.environ.get("CLAUDE_LOCATION", "global"))

_init_vertex_env()

# Classifier — Gemini 3.5 Flash (ADK 네이티브)
CLASSIFIER_LLM = "gemini-3.5-flash"

# Direct Answer — Gemini 3.1 Flash Lite (ADK 네이티브, 가벼운 응답용)
DIRECT_ANSWER_LLM = "gemini-3.1-flash-lite"

# Finalizer — Claude Haiku 4.5 (정확한 JSON→마크다운 변환)
FINALIZER_LLM = LiteLlm(model="vertex_ai/claude-haiku-4-5@20251001")

# Email Feedback — Claude Sonnet 4.6 (승인/거부/수정 의도 정확 판단)
EMAIL_FEEDBACK_LLM = LiteLlm(model="vertex_ai/claude-sonnet-4-6")


# ============================================================
# 1. Classifier — 사용자 의도 분류 + 파라미터 추출
#    출력: ClassificationResult (Pydantic), state["classification"]에 저장
#    모델: Gemini 3.5 Flash
# ============================================================

def build_classifier_agent() -> LlmAgent:
    """classifier LlmAgent를 생성한다 (today/members를 매번 최신화)."""
    KST = timezone(timedelta(hours=9))
    today = datetime.now(KST).strftime("%Y-%m-%d (%A)")
    members = ", ".join(ALL_MEMBERS.keys())
    return LlmAgent(
        name="classifier",
        model=CLASSIFIER_LLM,
        description="Classifies user intent and extracts task parameters.",
        instruction=build_classify_instruction(today=today, members=members),
        output_schema=ClassificationResult,
        output_key="classification",
        disallow_transfer_to_parent=True,
        disallow_transfer_to_peers=True,
    )


# ============================================================
# 2. Direct Answer — 5가지 작업과 무관한 일반 응답
#    모델: Gemini 3.1 Flash Lite
# ============================================================

direct_answer_agent = LlmAgent(
    name="direct_answer",
    model=DIRECT_ANSWER_LLM,
    description="Handles greetings, small talk, and usage questions.",
    instruction=DIRECT_ANSWER_INSTRUCTION,
    output_key="final_answer",
)


# ============================================================
# 3. Finalizer — 도구 결과(JSON)를 한국어 마크다운으로 변환
#    모델: Claude Haiku 4.5
# ============================================================

finalizer_agent = LlmAgent(
    name="finalizer",
    model=FINALIZER_LLM,
    description="Converts a tool result JSON into a Korean Markdown response.",
    instruction=FINALIZE_INSTRUCTION,
    output_key="final_answer",
)