"""ge_adk_agent 패키지.

ADK(Agent Development Kit) 기반 Dooray 사내 어시스턴트.
Vertex AI Agent Engine 배포 후 Gemini Enterprise(Agentspace)에
Custom Agent로 등록하여 사용한다.
"""

from .agent import root_agent

__all__ = ["root_agent"]
