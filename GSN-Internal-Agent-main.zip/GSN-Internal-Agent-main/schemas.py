"""의도 분류 노드의 Pydantic 출력 스키마.

LLM의 `with_structured_output()`로 강제되는 형식.
사용자 한 메시지에서 의도와 가능한 파라미터를 한 번에 추출.
"""

from __future__ import annotations

from typing import Literal, Optional

from pydantic import BaseModel, Field


class ClassificationResult(BaseModel):
    """의도 분류 + 파라미터 추출 결과."""

    intent: Literal[
        "list_records",
        "list_sa",
        "create_record",
        "add_comment",
        "send_email",
        "direct_answer",
    ] = Field(
        description=(
            "사용자 의도. "
            "list_records = Cloud-기록(미팅기록/주간보고) 조회. "
            "list_sa = Cloud-SA-요청 조회. "
            "create_record = 새 미팅기록 또는 주간업무보고 생성. "
            "add_comment = DX파트-업무에 댓글 추가. "
            "send_email = 이메일 초안 작성 및 전송. "
            "direct_answer = 인사/사용법/그 외 일반 질문 (라우팅 불필요)."
        )
    )

    # ===== 공통 추출 항목 =====
    customer: Optional[str] = Field(
        default=None,
        description="고객사명 (예: '삼성전자', '현대자동차'). 사용자가 언급하지 않으면 null.",
    )
    assignee_name: Optional[str] = Field(
        default=None,
        description="담당자 이름 (예: '김민형'). GS네오텍 직원 이름만. 언급 없으면 null.",
    )

    # ===== 1번/2번 공통: 조회 기간 =====
    lookup_days: Optional[int] = Field(
        default=None,
        description=(
            "조회 기간(일 수). 기본 30일. "
            "사용자가 '2달 전', '3개월 치', '60일' 등 기간을 언급하면 해당 일수로 변환. "
            "예: '2달' → 60, '3개월' → 90, '반년' → 180, '1년' → 365. "
            "언급 없으면 null (기본 30일 적용)."
        ),
    )

    # ===== 1번(list_records) 전용 =====
    tag_name: Optional[str] = Field(
        default=None,
        description="클라우드 태그. AWS/Azure/ChromeOS/Cloudflare/Datadog/GCP/GWS/NCP/Tencent 중 하나. 언급 없으면 null.",
    )

    # ===== 2번(list_sa) 전용 =====
    sa_status: Optional[str] = Field(
        default=None,
        description="SA 요청 상태. '요청 검토 중' 또는 '배정 완료' 둘 중 하나만. 언급 없으면 null.",
    )

    # ===== 3번(create_record) 공통 =====
    record_type: Optional[Literal["미팅기록", "주간업무보고"]] = Field(
        default=None,
        description=(
            "생성할 기록 유형. '미팅기록' 또는 '주간업무보고'. "
            "사용자가 '미팅기록 만들어줘'면 '미팅기록', '주간보고 작성해줘'면 '주간업무보고'. "
            "유형을 특정할 수 없으면 null (사용자에게 재질문)."
        ),
    )

    # ===== 3번: 미팅기록 전용 =====
    meeting_date: Optional[str] = Field(
        default=None,
        description="미팅 날짜를 YYYY-MM-DD 형식으로. 상대 날짜는 현재 날짜 기준 변환.",
    )
    meeting_time: Optional[str] = Field(
        default=None, description="미팅 시간 (예: '13:00 ~ 14:00').",
    )
    location: Optional[str] = Field(
        default=None, description="미팅 장소 (예: '화상 미팅', '서울 강남구 선릉로 428').",
    )
    gs_attendees: Optional[str] = Field(
        default=None,
        description="GS네오텍 참석자 (쉼표 구분, 첫 번째=영업, 두 번째=SA. 예: '강서원,김준재').",
    )
    customer_attendees: Optional[str] = Field(
        default=None, description="고객사 참석자 (선택). 쉼표 구분.",
    )
    cloud_type: Optional[str] = Field(
        default=None,
        description="클라우드 유형 (선택). AWS/Azure/GCP/GWS/NCP 등.",
    )
    other_attendees: Optional[str] = Field(
        default=None, description="기타 참석자 (선택). 소속 포함.",
    )
    history: Optional[str] = Field(
        default=None, description="미팅 히스토리. 해당 미팅 발생 히스토리, SA요청 내용 등.",
    )
    content: Optional[str] = Field(
        default=None, description="미팅 내용 또는 주간업무보고 본문 (마크다운 가능).",
    )
    action_items: Optional[str] = Field(
        default=None, description="해야 할 일 (미팅 이후 Next Step). 미팅기록 전용.",
    )

    # ===== 3번: 주간업무보고 전용 =====
    week_info: Optional[str] = Field(
        default=None,
        description="주차 정보 (예: '5월 2주차', '05월 1주차'). 주간업무보고 시 필수.",
    )
    project_name: Optional[str] = Field(
        default=None,
        description="프로젝트/업무명 (예: 'AWS MSP 프로젝트', 'MLOps 고도화'). 주간업무보고 시 필수.",
    )

    # ===== 5번(send_email) 전용 =====
    email_sender: Optional[str] = Field(
        default=None,
        description="보내는 사람 이메일 주소 (예: 'haalsgud97@gsneotek.com').",
    )
    email_recipient: Optional[str] = Field(
        default=None,
        description="받는 사람 이메일 주소 (예: 'someone@example.com'). 여러 명이면 쉼표 구분.",
    )
    email_subject: Optional[str] = Field(
        default=None,
        description="이메일 제목.",
    )
    email_body: Optional[str] = Field(
        default=None,
        description="이메일 본문 내용.",
    )
    email_cc: Optional[str] = Field(
        default=None,
        description="참조(CC) 이메일 주소 (선택). 여러 명이면 쉼표 구분.",
    )

    # ===== 6번(add_comment) 전용 =====
    post_id: Optional[str] = Field(
        default=None,
        description="댓글 달 DX 업무 ID. 사용자가 직접 ID를 언급한 경우만 채움. 모르면 null.",
    )
    comment_keyword: Optional[str] = Field(
        default=None,
        description="post_id를 모를 때 업무 검색용 키워드.",
    )
    comment_content: Optional[str] = Field(
        default=None, description="추가할 댓글 본문 (마크다운 가능).",
    )
