"""ge_adk_agent 진입점.

ADK CLI (`adk web`, `adk run`) 와 Vertex AI Agent Engine 배포가 이 모듈의 `root_agent`를 참조.
"""

from __future__ import annotations

import os

from dotenv import load_dotenv

# 패키지 내부 .env 우선 로드 (cwd 무관)
load_dotenv(os.path.join(os.path.dirname(__file__), ".env"))

from .orchestrator import DoorayOrchestrator
from .sub_agents import build_classifier_agent, direct_answer_agent, finalizer_agent

# 매 import마다 today/members가 최신 상태로 반영되도록 build_classifier_agent 사용
root_agent = DoorayOrchestrator(
    name="dooray_orchestrator",
    classifier=build_classifier_agent(),
    direct_answer=direct_answer_agent,
    finalizer=finalizer_agent,
)