"""Dooray REST API 호출 함수.

오케스트레이터의 각 액션 단계에서 호출되는 thin wrapper.
모든 함수는 JSON 직렬화 가능한 dict를 반환 (finalizer LLM이 마크다운으로 변환).

6개 함수:
  1. list_cloud_records    — Cloud-기록 조회 (고객사/태그/담당자/기간 필터)
  2. list_sa_requests      — SA-요청 조회 (고객사/상태/담당자/기간 필터)
  3. create_meeting_record — 미팅기록 자동 생성 (Cloud-기록_미팅기록_v1.0 양식)
  4. create_weekly_report  — 주간업무보고 자동 생성 (Cloud-기록_주간업무보고_v1.0 양식)
  5. list_dx_tasks         — DX 업무 검색 (댓글 추가용 post_id 확인)
  6. add_dx_task_comment   — DX 업무 댓글 추가

※ Gmail 전송은 별도 모듈 gmail_tools.py 참조.
"""

from __future__ import annotations

import os
from datetime import datetime
from typing import Optional

import requests

from .config import (
    ALL_MEMBERS,
    CLOUD_RECORD_TAGS,
    DEFAULT_LOOKUP_DAYS,
    DEFAULT_PAGE_SIZE,
    DOORAY_API_BASE,
    DOORAY_WEB_BASE,
    PROJECT_CLOUD_RECORD,
    PROJECT_DX_TASK,
    PROJECT_SA_REQUEST,
    SA_REQUEST_WORKFLOWS,
    WEEKDAYS_KR,
)


# ============================================================
# 공통 헬퍼
# ============================================================

def _headers() -> dict:
    """Dooray API 인증 헤더 — 호출 시점에 환경변수를 읽어 토큰 변경에 즉시 반응."""
    token = os.environ.get("DOORAY_API_TOKEN", "")
    return {"Authorization": f"dooray-api {token}"}


def _summarize_post(post: dict, project_id: str) -> dict:
    """Dooray 업무 응답을 요약 dict로 변환 + Dooray 링크 생성."""
    # 작성자
    author = (
        post.get("users", {}).get("from", {}).get("member", {}).get("name", "")
    )

    # 담당자 목록
    assignees = [
        u.get("member", {}).get("name", "")
        for u in post.get("users", {}).get("to", [])
        if u.get("member")
    ]

    post_id = post.get("id", "")
    return {
        "id": post_id,
        "subject": post.get("subject", ""),
        "task_number": post.get("taskNumber", ""),
        "created_at": post.get("createdAt", ""),
        "author": author,
        "assignees": assignees,
        "workflow": post.get("workflow", {}).get("name", ""),
        "dooray_url": f"{DOORAY_WEB_BASE}/task/{project_id}/{post_id}" if post_id else "",
    }


def _filter_by_customer(posts: list[dict], customer: Optional[str]) -> list[dict]:
    """제목에 고객사명이 부분일치하는 업무만 남긴다 (대소문자 무시)."""
    if not customer:
        return posts
    needle = customer.strip().lower()
    if not needle:
        return posts
    return [p for p in posts if needle in p.get("subject", "").lower()]


def _resolve_member_id(name: Optional[str]) -> tuple[Optional[str], Optional[str], Optional[str]]:
    """담당자 이름 → (member_id, matched_name, error_message).

    정확 일치 우선, 없으면 부분일치(대소문자 무시) 시도.
    """
    if not name:
        return None, None, None
    name = name.strip()
    if not name:
        return None, None, None

    # 정확 일치
    if name in ALL_MEMBERS:
        return ALL_MEMBERS[name], name, None

    # 부분일치 (대소문자 무시)
    needle = name.lower()
    matches = [
        (n, mid) for n, mid in ALL_MEMBERS.items()
        if needle in n.lower() or n.lower() in needle
    ]
    if len(matches) == 1:
        return matches[0][1], matches[0][0], None
    if len(matches) > 1:
        names = ", ".join(m[0] for m in matches)
        return None, None, f"'{name}'에 해당하는 멤버가 여러 명입니다: {names}. 정확한 이름을 알려주세요."

    return None, None, f"'{name}' 멤버를 찾을 수 없습니다. 5개 팀(AI센터/SI파트/Cloud팀/Datadog/DX파트) 내 정확한 이름을 확인해주세요."


def _build_web_filter_url(project_id: str, **params) -> str:
    """Dooray 웹 UI 필터 URL 생성."""
    base = f"{DOORAY_WEB_BASE}/task/{project_id}"
    query = [f"{k}={v}" for k, v in params.items() if v]
    return f"{base}?{'&'.join(query)}" if query else base


def _fetch_posts_within_days(
    project_id: str, days: int, extra_params: Optional[dict] = None
) -> list[dict]:
    """프로젝트에서 최근 N일 이내 생성된 업무를 페이지네이션으로 수집한다.

    Dooray API는 날짜 필터 파라미터를 지원하지 않으므로,
    -createdAt 정렬 후 생성일이 기준일 이전이면 수집을 중단한다.
    """
    from datetime import timezone
    cutoff = datetime.now(timezone.utc) - timedelta(days=days)
    collected: list[dict] = []
    page = 0

    while page < 10:
        params: dict = {
            "page": page,
            "size": DEFAULT_PAGE_SIZE,
            "order": "-createdAt",
            **(extra_params or {}),
        }
        try:
            resp = requests.get(
                f"{DOORAY_API_BASE}/projects/{project_id}/posts",
                headers=_headers(),
                params=params,
                timeout=30,
            )
            resp.raise_for_status()
            posts = resp.json().get("result", [])
        except Exception:
            break

        if not posts:
            break

        for post in posts:
            created_str = post.get("createdAt", "")
            try:
                created_dt = datetime.fromisoformat(created_str.replace("Z", "+00:00"))
            except ValueError:
                continue
            if created_dt < cutoff:
                return collected
            collected.append(post)

        page += 1

    return collected


# ============================================================
# 1. Cloud-기록 조회
# ============================================================

def list_cloud_records(
    customer: Optional[str] = None,
    tag_name: Optional[str] = None,
    assignee_name: Optional[str] = None,
    days: Optional[int] = None,
) -> dict:
    """Cloud-기록 프로젝트 업무 조회.

    Args:
        customer: 고객사명 (제목 부분일치, 대소문자 무시).
        tag_name: 태그 이름 — AWS/Azure/ChromeOS/Cloudflare/Datadog/GCP/GWS/NCP/Tencent.
        assignee_name: 담당자 이름 (5개 팀 멤버 중 한 명).
        days: 조회 기간 (일 수). None이면 기본값(30) 사용.
    """
    lookup_days = days or DEFAULT_LOOKUP_DAYS

    # 1) 태그명 → ID
    tag_id = None
    if tag_name:
        tag_id = CLOUD_RECORD_TAGS.get(tag_name.strip().lower())
        if not tag_id:
            return {
                "error": f"알 수 없는 태그: {tag_name}. 가능한 태그: {', '.join(sorted(CLOUD_RECORD_TAGS.keys()))}",
                "project": "Cloud-기록",
            }

    # 2) 담당자 이름 → ID
    member_id, matched_name, member_err = _resolve_member_id(assignee_name)
    if member_err:
        return {"error": member_err, "project": "Cloud-기록"}

    # 3) API 호출 파라미터
    params: dict = {
        "page": 0,
        "size": DEFAULT_PAGE_SIZE,
        "order": "-createdAt",
        "createdAt": f"prev-{lookup_days}d",
    }
    if tag_id:
        params["tagIds"] = tag_id
    if member_id:
        params["toMemberIds"] = member_id

    try:
        resp = requests.get(
            f"{DOORAY_API_BASE}/projects/{PROJECT_CLOUD_RECORD}/posts",
            headers=_headers(),
            params=params,
            timeout=30,
        )
        resp.raise_for_status()
        raw = resp.json().get("result", [])
    except Exception as e:
        return {"project": "Cloud-기록", "error": f"Dooray API 호출 실패: {e}"}

    posts = [_summarize_post(p, PROJECT_CLOUD_RECORD) for p in raw]
    filtered = _filter_by_customer(posts, customer)

    # 4) 응답
    filter_desc = []
    if customer: filter_desc.append(f"고객사='{customer}'")
    if tag_name: filter_desc.append(f"태그='{tag_name}'")
    if matched_name: filter_desc.append(f"담당자='{matched_name}'")
    if not filter_desc: filter_desc.append("필터 없음 (최신순)")

    return {
        "project": "Cloud-기록",
        "period": f"최근 {lookup_days}일",
        "filter_applied": " / ".join(filter_desc),
        "total_count": len(filtered),
        "posts": filtered[:20],
        "filter_url": _build_web_filter_url(
            PROJECT_CLOUD_RECORD,
            tags=f"and,{tag_id}" if tag_id else None,
            to=member_id,
        ),
    }


# ============================================================
# 2. Cloud-SA-요청 조회
# ============================================================

def list_sa_requests(
    customer: Optional[str] = None,
    status: Optional[str] = None,
    assignee_name: Optional[str] = None,
    days: Optional[int] = None,
) -> dict:
    """Cloud-SA-요청 프로젝트 조회.

    Args:
        customer: 고객사명 (제목 부분일치).
        status: 요청 상태 — '요청 검토 중' 또는 '배정 완료'.
        assignee_name: 담당자 이름.
        days: 조회 기간 (일 수). None이면 기본값(30) 사용.
    """
    lookup_days = days or DEFAULT_LOOKUP_DAYS
    workflow_id = None
    if status:
        workflow_id = SA_REQUEST_WORKFLOWS.get(status.strip())
        if not workflow_id:
            return {
                "error": f"알 수 없는 상태: {status}. 가능한 상태: {', '.join(SA_REQUEST_WORKFLOWS.keys())}",
                "project": "Cloud-SA-요청",
            }

    member_id, matched_name, member_err = _resolve_member_id(assignee_name)
    if member_err:
        return {"error": member_err, "project": "Cloud-SA-요청"}

    params: dict = {
        "page": 0,
        "size": DEFAULT_PAGE_SIZE,
        "order": "-createdAt",
        "createdAt": f"prev-{lookup_days}d",
    }
    if workflow_id:
        params["postWorkflowIds"] = workflow_id
    if member_id:
        params["toMemberIds"] = member_id

    try:
        resp = requests.get(
            f"{DOORAY_API_BASE}/projects/{PROJECT_SA_REQUEST}/posts",
            headers=_headers(),
            params=params,
            timeout=30,
        )
        resp.raise_for_status()
        raw = resp.json().get("result", [])
    except Exception as e:
        return {"project": "Cloud-SA-요청", "error": f"Dooray API 호출 실패: {e}"}

    posts = [_summarize_post(p, PROJECT_SA_REQUEST) for p in raw]
    filtered = _filter_by_customer(posts, customer)

    filter_desc = []
    if customer: filter_desc.append(f"고객사='{customer}'")
    if status: filter_desc.append(f"상태='{status}'")
    if matched_name: filter_desc.append(f"담당자='{matched_name}'")
    if not filter_desc: filter_desc.append("필터 없음 (최신순)")

    return {
        "project": "Cloud-SA-요청",
        "period": f"최근 {lookup_days}일",
        "filter_applied": " / ".join(filter_desc),
        "total_count": len(filtered),
        "posts": filtered[:20],
        "filter_url": _build_web_filter_url(
            PROJECT_SA_REQUEST,
            workflowIds=workflow_id,
            to=member_id,
        ),
    }


# ============================================================
# 3. 미팅기록 자동 생성
# ============================================================

def create_meeting_record(
    customer: str,
    meeting_date: str,
    meeting_time: str,
    location: str,
    gs_attendees: str,
    content: str,
    customer_attendees: Optional[str] = None,
    cloud_type: Optional[str] = None,
    other_attendees: Optional[str] = None,
    history: Optional[str] = None,
    action_items: Optional[str] = None,
) -> dict:
    """Cloud-기록 프로젝트에 미팅기록 업무를 생성한다.

    제목 형식: [미팅기록] 고객사명/YYMMDD/영업이름/SA이름
    본문 양식: 1.미팅 히스토리 → 2.고객사 정보 → 3.미팅 참석자 → 4.미팅 내용 → 5.해야 할 일
    """
    # 1) 태그 결정 (cloud_type 선택)
    tag_ids = []
    if cloud_type:
        tag_id = CLOUD_RECORD_TAGS.get(cloud_type.strip().lower())
        if tag_id:
            tag_ids.append(tag_id)

    # 2) 날짜 파싱
    try:
        date_obj = datetime.strptime(meeting_date, "%Y-%m-%d")
    except ValueError:
        return {
            "success": False,
            "error": f"meeting_date 형식 오류: {meeting_date}. YYYY-MM-DD 형식 필요.",
        }
    yymmdd = date_obj.strftime("%y%m%d")
    weekday = WEEKDAYS_KR[date_obj.weekday()]
    date_display = f"{date_obj.strftime('%Y.%m.%d')}({weekday}) {meeting_time}"

    # 3) GS 참석자 파싱 → 제목 구성 (첫 번째=영업, 두 번째=SA)
    gs_names = [n.strip() for n in gs_attendees.split(",") if n.strip()]
    if not gs_names:
        return {"success": False, "error": "gs_attendees가 비어있습니다."}
    sales = gs_names[0]
    sa = ",".join(gs_names[1:])
    title = f"[미팅기록] {customer}/{yymmdd}/{sales}" + (f"/{sa}" if sa else "")

    # 4) 본문 마크다운 (공식 양식: Cloud-기록_미팅기록_v1.0)
    body = [
        "## 1. 미팅 히스토리\n",
        history or "(해당 미팅 발생 히스토리에 대해 기술, SA요청 내용)",
        "",
        "## 2. 고객사 정보\n",
        f"- 고객사 : {customer}",
        f"- 일시 : {date_display}",
        f"- 장소 : {location}",
        "",
        "## 3. 미팅 참석자\n",
        f"- 고객사 : {customer_attendees or ''}",
        f"- GS네오텍 : {', '.join(gs_names)}",
    ]
    if other_attendees:
        for line in other_attendees.strip().split("\n"):
            line = line.strip()
            if line:
                body.append(f"- (기타) : {line}" if not line.startswith("-") else line)
    body.extend([
        "",
        "## 4. 미팅 내용\n",
        content,
        "",
        "## 5. 해야 할 일\n",
        action_items or "(미팅 이후 Next Step에 필요한 작업에 대한 리스트)",
    ])

    # 5) API 호출
    request_body = {
        "subject": title,
        "body": {"mimeType": "text/x-markdown", "content": "\n".join(body)},
        "tagIds": tag_ids,
        "priority": "none",
    }
    try:
        resp = requests.post(
            f"{DOORAY_API_BASE}/projects/{PROJECT_CLOUD_RECORD}/posts",
            headers={**_headers(), "Content-Type": "application/json"},
            json=request_body,
            timeout=30,
        )
        resp.raise_for_status()
        result = resp.json().get("result", {})
    except Exception as e:
        return {"success": False, "error": f"Dooray API 호출 실패: {e}"}

    post_id = result.get("id", "")
    return {
        "success": True,
        "post_id": post_id,
        "title": title,
        "dooray_url": f"{DOORAY_WEB_BASE}/task/{PROJECT_CLOUD_RECORD}/{post_id}" if post_id else "",
        "message": "미팅기록이 생성되었습니다.",
    }


# ============================================================
# 3-b. 주간업무보고 자동 생성
# ============================================================

def create_weekly_report(
    customer: str,
    week_info: str,
    project_name: str,
    content: str,
    cloud_type: Optional[str] = None,
) -> dict:
    """Cloud-기록 프로젝트에 주간업무보고를 생성한다.

    제목 형식: [주간업무보고] 고객사명/MM월 X주차/업무(프로젝트)명
    본문 양식: 업무(프로젝트)명 → 1.개요(금주현황/차주계획) → 2.진행 일정 및 계획 → 3.진행 내용
    """
    title = f"[주간업무보고] {customer}/{week_info}/{project_name}"

    # 태그 (선택)
    tag_ids = []
    if cloud_type:
        tag_id = CLOUD_RECORD_TAGS.get(cloud_type.strip().lower())
        if tag_id:
            tag_ids.append(tag_id)

    # 본문 마크다운 (공식 양식: Cloud-기록_주간업무보고_v1.0)
    body = "\n".join([
        f"## 업무(프로젝트) 명 : {project_name}\n",
        "## 1. 개요\n",
        content,
        "",
        "## 2. 진행 일정 및 계획\n",
        "| 순서 | 내용 | 일자 | 인원 | 작업 단계 |",
        "|------|------|------|------|-----------|",
        "| 1    |      |      |      |           |",
        "",
        "## 3. 진행 내용\n",
        "| 순서 | 업무 명 | 진행 내용 |",
        "|------|---------|-----------|",
        "|      |         |           |",
    ])

    request_body = {
        "subject": title,
        "body": {"mimeType": "text/x-markdown", "content": body},
        "tagIds": tag_ids,
        "priority": "none",
    }
    try:
        resp = requests.post(
            f"{DOORAY_API_BASE}/projects/{PROJECT_CLOUD_RECORD}/posts",
            headers={**_headers(), "Content-Type": "application/json"},
            json=request_body,
            timeout=30,
        )
        resp.raise_for_status()
        result = resp.json().get("result", {})
    except Exception as e:
        return {"success": False, "error": f"Dooray API 호출 실패: {e}"}

    post_id = result.get("id", "")
    return {
        "success": True,
        "post_id": post_id,
        "title": title,
        "dooray_url": f"{DOORAY_WEB_BASE}/task/{PROJECT_CLOUD_RECORD}/{post_id}" if post_id else "",
        "message": "주간업무보고가 생성되었습니다.",
    }


# ============================================================
# 4. DX파트-업무 조회 (댓글 추가용 사전 검색)
# ============================================================

def list_dx_tasks(
    assignee_name: Optional[str] = None,
    keyword: Optional[str] = None,
    size: int = 20,
) -> dict:
    """DX파트-업무 검색 (post_id 확인용).

    Args:
        assignee_name: 담당자 이름 (5개 팀 멤버 중 한 명).
        keyword: 제목 부분일치 검색어 (고객사명/업무 키워드).
        size: 조회 건수 (기본 20).
    """
    member_id, matched_name, member_err = _resolve_member_id(assignee_name)
    if member_err:
        return {"error": member_err, "project": "DX파트-업무"}

    params: dict = {
        "page": 0,
        "size": DEFAULT_PAGE_SIZE if keyword else size,
        "order": "-createdAt",
    }
    if member_id:
        params["toMemberIds"] = member_id

    try:
        resp = requests.get(
            f"{DOORAY_API_BASE}/projects/{PROJECT_DX_TASK}/posts",
            headers=_headers(),
            params=params,
            timeout=30,
        )
        resp.raise_for_status()
        raw = resp.json().get("result", [])
    except Exception as e:
        return {"project": "DX파트-업무", "error": f"Dooray API 호출 실패: {e}"}

    posts = [_summarize_post(p, PROJECT_DX_TASK) for p in raw]

    if keyword:
        needle = keyword.strip().lower()
        posts = [p for p in posts if needle in p.get("subject", "").lower()]

    return {
        "project": "DX파트-업무",
        "assignee": matched_name or "전체",
        "keyword": keyword or "",
        "total_count": len(posts),
        "tasks": posts[:size],
        "filter_url": _build_web_filter_url(PROJECT_DX_TASK, to=member_id),
    }


# ============================================================
# 5. DX파트-업무 댓글 추가
# ============================================================

def add_dx_task_comment(post_id: str, content: str) -> dict:
    """DX파트-업무 특정 업무에 댓글 추가.

    Args:
        post_id: 업무 ID (필수, list_dx_tasks 결과의 id).
        content: 댓글 내용 (필수, 마크다운 지원).
    """
    if not post_id or not post_id.strip():
        return {"success": False, "error": "post_id가 비어있습니다."}
    if not content or not content.strip():
        return {"success": False, "error": "댓글 내용이 비어있습니다."}

    request_body = {
        "body": {"mimeType": "text/x-markdown", "content": content}
    }
    try:
        resp = requests.post(
            f"{DOORAY_API_BASE}/projects/{PROJECT_DX_TASK}/posts/{post_id}/logs",
            headers={**_headers(), "Content-Type": "application/json"},
            json=request_body,
            timeout=30,
        )
        resp.raise_for_status()
        result = resp.json().get("result", {})
    except Exception as e:
        return {"success": False, "error": f"Dooray API 호출 실패: {e}"}

    return {
        "success": True,
        "log_id": result.get("id", ""),
        "post_id": post_id,
        "dooray_url": f"{DOORAY_WEB_BASE}/task/{PROJECT_DX_TASK}/{post_id}",
        "message": "댓글이 추가되었습니다.",
    }
